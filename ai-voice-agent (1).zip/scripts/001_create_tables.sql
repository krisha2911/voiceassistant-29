-- Create database schema for AI Voice Agent metrics

-- Sessions table to track user sessions
CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    participant_id VARCHAR(255) NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    end_time TIMESTAMP WITH TIME ZONE,
    duration_ms INTEGER,
    total_interactions INTEGER DEFAULT 0,
    average_latency DECIMAL(10,2),
    error_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Metrics table to store all performance metrics
CREATE TABLE IF NOT EXISTS metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(id) ON DELETE CASCADE,
    metric_type VARCHAR(50) NOT NULL,
    latency_ms DECIMAL(10,2),
    ttft_ms DECIMAL(10,2), -- Time to First Token
    ttfb_ms DECIMAL(10,2), -- Time to First Byte
    timestamp_recorded TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    additional_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations table to track user interactions
CREATE TABLE IF NOT EXISTS conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(id) ON DELETE CASCADE,
    user_input TEXT,
    ai_response TEXT,
    total_pipeline_latency_ms DECIMAL(10,2),
    stt_latency_ms DECIMAL(10,2),
    llm_latency_ms DECIMAL(10,2),
    tts_latency_ms DECIMAL(10,2),
    timestamp_started TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    timestamp_completed TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Errors table to track system errors
CREATE TABLE IF NOT EXISTS errors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID REFERENCES sessions(id) ON DELETE SET NULL,
    error_type VARCHAR(100),
    error_message TEXT,
    error_stack TEXT,
    timestamp_occurred TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_metrics_session_id ON metrics(session_id);
CREATE INDEX IF NOT EXISTS idx_metrics_type ON metrics(metric_type);
CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON metrics(timestamp_recorded);
CREATE INDEX IF NOT EXISTS idx_conversations_session_id ON conversations(session_id);
CREATE INDEX IF NOT EXISTS idx_sessions_participant ON sessions(participant_id);
CREATE INDEX IF NOT EXISTS idx_sessions_start_time ON sessions(start_time);

-- Create a view for easy metrics analysis
CREATE OR REPLACE VIEW metrics_summary AS
SELECT 
    s.id as session_id,
    s.participant_id,
    s.start_time,
    s.duration_ms as session_duration_ms,
    COUNT(c.id) as total_conversations,
    AVG(c.total_pipeline_latency_ms) as avg_total_latency,
    AVG(c.stt_latency_ms) as avg_stt_latency,
    AVG(c.llm_latency_ms) as avg_llm_latency,
    AVG(c.tts_latency_ms) as avg_tts_latency,
    COUNT(e.id) as error_count,
    (COUNT(c.id) - COUNT(e.id))::DECIMAL / NULLIF(COUNT(c.id), 0) * 100 as success_rate
FROM sessions s
LEFT JOIN conversations c ON s.id = c.session_id
LEFT JOIN errors e ON s.id = e.session_id
GROUP BY s.id, s.participant_id, s.start_time, s.duration_ms;

COMMENT ON TABLE sessions IS 'Tracks user sessions with the AI voice agent';
COMMENT ON TABLE metrics IS 'Stores detailed performance metrics for each component';
COMMENT ON TABLE conversations IS 'Records complete user-AI interactions';
COMMENT ON TABLE errors IS 'Logs system errors and failures';
COMMENT ON VIEW metrics_summary IS 'Aggregated view of session performance metrics';
