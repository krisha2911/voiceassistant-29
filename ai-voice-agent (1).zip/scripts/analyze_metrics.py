import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import glob
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class MetricsAnalyzer:
    def __init__(self, data_dir='data'):
        self.data_dir = Path(data_dir)
        self.metrics_data = []
        self.load_all_metrics()
    
    def load_all_metrics(self):
        """Load all Excel files from the data directory"""
        excel_files = glob.glob(str(self.data_dir / "*.xlsx"))
        
        if not excel_files:
            print("❌ No Excel files found in data directory")
            return
        
        print(f"📊 Loading {len(excel_files)} Excel files...")
        
        for file_path in excel_files:
            try:
                df = pd.read_excel(file_path)
                df['source_file'] = Path(file_path).name
                self.metrics_data.append(df)
                print(f"✅ Loaded {file_path}")
            except Exception as e:
                print(f"❌ Failed to load {file_path}: {e}")
        
        if self.metrics_data:
            self.combined_df = pd.concat(self.metrics_data, ignore_index=True)
            print(f"📈 Combined dataset: {len(self.combined_df)} records")
        else:
            print("❌ No data loaded")
    
    def analyze_latency_metrics(self):
        """Analyze latency metrics and identify bottlenecks"""
        if not hasattr(self, 'combined_df'):
            print("❌ No data available for analysis")
            return
        
        print("\n🔍 LATENCY ANALYSIS")
        print("=" * 50)
        
        # Filter latency metrics
        latency_metrics = self.combined_df[
            self.combined_df['Metric Type'].str.contains('latency', na=False)
        ].copy()
        
        if latency_metrics.empty:
            print("❌ No latency metrics found")
            return
        
        # Convert latency to numeric
        latency_metrics['Latency (ms)'] = pd.to_numeric(
            latency_metrics['Latency (ms)'], errors='coerce'
        )
        
        # Overall statistics
        print("\n📊 Overall Latency Statistics:")
        for metric_type in latency_metrics['Metric Type'].unique():
            if pd.isna(metric_type):
                continue
                
            subset = latency_metrics[latency_metrics['Metric Type'] == metric_type]
            latencies = subset['Latency (ms)'].dropna()
            
            if len(latencies) > 0:
                print(f"\n{metric_type.upper()}:")
                print(f"  Average: {latencies.mean():.1f}ms")
                print(f"  Median:  {latencies.median():.1f}ms")
                print(f"  Min:     {latencies.min():.1f}ms")
                print(f"  Max:     {latencies.max():.1f}ms")
                print(f"  Std Dev: {latencies.std():.1f}ms")
                
                # Performance targets
                if metric_type == 'total_latency':
                    under_2s = (latencies < 2000).sum()
                    total = len(latencies)
                    percentage = (under_2s / total) * 100
                    print(f"  Under 2s: {under_2s}/{total} ({percentage:.1f}%)")
                    
                    if percentage < 80:
                        print("  ⚠️  WARNING: Less than 80% of responses under 2s target")
                    else:
                        print("  ✅ Good: Most responses meet 2s target")
    
    def identify_bottlenecks(self):
        """Identify performance bottlenecks in the pipeline"""
        print("\n🔍 BOTTLENECK ANALYSIS")
        print("=" * 50)
        
        if not hasattr(self, 'combined_df'):
            return
        
        # Calculate average latencies by component
        components = ['stt_latency', 'llm_latency', 'tts_latency']
        bottlenecks = {}
        
        for component in components:
            subset = self.combined_df[
                self.combined_df['Metric Type'] == component
            ]
            if not subset.empty:
                latencies = pd.to_numeric(subset['Latency (ms)'], errors='coerce').dropna()
                if len(latencies) > 0:
                    bottlenecks[component] = latencies.mean()
        
        if bottlenecks:
            print("\n📊 Average Component Latencies:")
            sorted_bottlenecks = sorted(bottlenecks.items(), key=lambda x: x[1], reverse=True)
            
            for i, (component, avg_latency) in enumerate(sorted_bottlenecks):
                status = "🔴" if i == 0 else "🟡" if i == 1 else "🟢"
                print(f"  {status} {component.replace('_', ' ').title()}: {avg_latency:.1f}ms")
            
            # Recommendations
            slowest_component = sorted_bottlenecks[0][0]
            print(f"\n💡 OPTIMIZATION RECOMMENDATIONS:")
            
            if slowest_component == 'stt_latency':
                print("  • Consider using a faster STT model or service")
                print("  • Optimize audio preprocessing")
                print("  • Check network latency to STT service")
            elif slowest_component == 'llm_latency':
                print("  • Use a smaller/faster LLM model")
                print("  • Implement response streaming")
                print("  • Reduce context window size")
                print("  • Consider local LLM deployment")
            elif slowest_component == 'tts_latency':
                print("  • Use a faster TTS model")
                print("  • Implement audio streaming")
                print("  • Optimize voice settings")
                print("  • Consider edge TTS deployment")
    
    def generate_performance_report(self):
        """Generate a comprehensive performance report"""
        print("\n📋 PERFORMANCE REPORT")
        print("=" * 50)
        
        if not hasattr(self, 'combined_df'):
            return
        
        # Count total interactions
        total_interactions = len(self.combined_df[
            self.combined_df['Metric Type'] == 'total_latency'
        ])
        
        # Calculate success rate (interactions without errors)
        error_count = len(self.combined_df[
            self.combined_df['Metric Type'] == 'error'
        ])
        
        success_rate = ((total_interactions - error_count) / total_interactions * 100) if total_interactions > 0 else 0
        
        print(f"Total Interactions: {total_interactions}")
        print(f"Errors: {error_count}")
        print(f"Success Rate: {success_rate:.1f}%")
        
        # Performance grade
        total_latency_data = self.combined_df[
            self.combined_df['Metric Type'] == 'total_latency'
        ]
        
        if not total_latency_data.empty:
            latencies = pd.to_numeric(total_latency_data['Latency (ms)'], errors='coerce').dropna()
            avg_latency = latencies.mean()
            under_2s_percent = (latencies < 2000).sum() / len(latencies) * 100
            
            # Grading system
            if avg_latency < 1000 and under_2s_percent > 95:
                grade = "A+ (Excellent)"
            elif avg_latency < 1500 and under_2s_percent > 90:
                grade = "A (Very Good)"
            elif avg_latency < 2000 and under_2s_percent > 80:
                grade = "B (Good)"
            elif avg_latency < 3000 and under_2s_percent > 60:
                grade = "C (Acceptable)"
            else:
                grade = "D (Needs Improvement)"
            
            print(f"Performance Grade: {grade}")
            print(f"Average Total Latency: {avg_latency:.1f}ms")
            print(f"Responses Under 2s: {under_2s_percent:.1f}%")
    
    def create_visualizations(self):
        """Create performance visualization charts"""
        if not hasattr(self, 'combined_df'):
            return
        
        print("\n📊 Creating performance visualizations...")
        
        # Set up the plotting style
        plt.style.use('seaborn-v0_8')
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('AI Voice Agent Performance Analysis', fontsize=16, fontweight='bold')
        
        # 1. Latency Distribution
        latency_data = self.combined_df[
            self.combined_df['Metric Type'] == 'total_latency'
        ]
        if not latency_data.empty:
            latencies = pd.to_numeric(latency_data['Latency (ms)'], errors='coerce').dropna()
            axes[0, 0].hist(latencies, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
            axes[0, 0].axvline(2000, color='red', linestyle='--', label='2s Target')
            axes[0, 0].set_title('Total Latency Distribution')
            axes[0, 0].set_xlabel('Latency (ms)')
            axes[0, 0].set_ylabel('Frequency')
            axes[0, 0].legend()
        
        # 2. Component Latency Comparison
        components = ['stt_latency', 'llm_latency', 'tts_latency']
        component_avgs = []
        component_names = []
        
        for component in components:
            subset = self.combined_df[self.combined_df['Metric Type'] == component]
            if not subset.empty:
                latencies = pd.to_numeric(subset['Latency (ms)'], errors='coerce').dropna()
                if len(latencies) > 0:
                    component_avgs.append(latencies.mean())
                    component_names.append(component.replace('_latency', '').upper())
        
        if component_avgs:
            bars = axes[0, 1].bar(component_names, component_avgs, color=['lightcoral', 'lightgreen', 'lightblue'])
            axes[0, 1].set_title('Average Component Latencies')
            axes[0, 1].set_ylabel('Latency (ms)')
            
            # Add value labels on bars
            for bar, avg in zip(bars, component_avgs):
                axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
                               f'{avg:.0f}ms', ha='center', va='bottom')
        
        # 3. Latency Over Time
        if 'Timestamp' in self.combined_df.columns:
            time_data = self.combined_df[
                self.combined_df['Metric Type'] == 'total_latency'
            ].copy()
            
            if not time_data.empty:
                time_data['Timestamp'] = pd.to_datetime(time_data['Timestamp'], errors='coerce')
                time_data = time_data.dropna(subset=['Timestamp'])
                time_data = time_data.sort_values('Timestamp')
                
                latencies = pd.to_numeric(time_data['Latency (ms)'], errors='coerce')
                axes[1, 0].plot(time_data['Timestamp'], latencies, marker='o', markersize=3, alpha=0.7)
                axes[1, 0].axhline(2000, color='red', linestyle='--', label='2s Target')
                axes[1, 0].set_title('Latency Over Time')
                axes[1, 0].set_xlabel('Time')
                axes[1, 0].set_ylabel('Latency (ms)')
                axes[1, 0].legend()
                axes[1, 0].tick_params(axis='x', rotation=45)
        
        # 4. Performance Summary
        axes[1, 1].axis('off')
        
        # Calculate summary stats
        total_latency_data = self.combined_df[
            self.combined_df['Metric Type'] == 'total_latency'
        ]
        
        if not total_latency_data.empty:
            latencies = pd.to_numeric(total_latency_data['Latency (ms)'], errors='coerce').dropna()
            
            summary_text = f"""
Performance Summary

Total Interactions: {len(latencies)}
Average Latency: {latencies.mean():.1f}ms
Median Latency: {latencies.median():.1f}ms
95th Percentile: {latencies.quantile(0.95):.1f}ms

Target Performance (< 2s):
{(latencies < 2000).sum()}/{len(latencies)} interactions
({(latencies < 2000).sum()/len(latencies)*100:.1f}%)

Fastest Response: {latencies.min():.1f}ms
Slowest Response: {latencies.max():.1f}ms
            """
            
            axes[1, 1].text(0.1, 0.9, summary_text, transform=axes[1, 1].transAxes,
                           fontsize=12, verticalalignment='top', fontfamily='monospace',
                           bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
        
        plt.tight_layout()
        
        # Save the plot
        output_path = self.data_dir / f'performance_analysis_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"📊 Visualization saved to: {output_path}")
        
        # Show the plot
        plt.show()
    
    def export_summary_report(self):
        """Export a summary report to Excel"""
        if not hasattr(self, 'combined_df'):
            return
        
        print("\n📄 Exporting summary report...")
        
        # Create summary statistics
        summary_data = []
        
        metric_types = ['stt_latency', 'llm_latency', 'tts_latency', 'total_latency']
        
        for metric_type in metric_types:
            subset = self.combined_df[self.combined_df['Metric Type'] == metric_type]
            if not subset.empty:
                latencies = pd.to_numeric(subset['Latency (ms)'], errors='coerce').dropna()
                
                if len(latencies) > 0:
                    summary_data.append({
                        'Metric': metric_type.replace('_', ' ').title(),
                        'Count': len(latencies),
                        'Average (ms)': round(latencies.mean(), 1),
                        'Median (ms)': round(latencies.median(), 1),
                        'Min (ms)': round(latencies.min(), 1),
                        'Max (ms)': round(latencies.max(), 1),
                        'Std Dev (ms)': round(latencies.std(), 1),
                        '95th Percentile (ms)': round(latencies.quantile(0.95), 1)
                    })
        
        # Create DataFrame and export
        summary_df = pd.DataFrame(summary_data)
        
        output_path = self.data_dir / f'performance_summary_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Add raw data
            if hasattr(self, 'combined_df'):
                self.combined_df.to_excel(writer, sheet_name='Raw Data', index=False)
        
        print(f"📄 Summary report exported to: {output_path}")

def main():
    """Main analysis function"""
    print("🚀 Starting AI Voice Agent Metrics Analysis")
    print("=" * 50)
    
    analyzer = MetricsAnalyzer()
    
    if not hasattr(analyzer, 'combined_df') or analyzer.combined_df.empty:
        print("❌ No data available for analysis. Please run the agent first to generate metrics.")
        return
    
    # Run all analyses
    analyzer.analyze_latency_metrics()
    analyzer.identify_bottlenecks()
    analyzer.generate_performance_report()
    analyzer.create_visualizations()
    analyzer.export_summary_report()
    
    print("\n✅ Analysis complete!")
    print("\n💡 Next Steps:")
    print("  1. Review the bottleneck analysis for optimization opportunities")
    print("  2. Check the performance visualizations")
    print("  3. Implement recommended optimizations")
    print("  4. Re-run tests to measure improvements")

if __name__ == "__main__":
    main()
