import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import psycopg2
from sqlalchemy import create_engine
import warnings
warnings.filterwarnings('ignore')

class DatabaseMetricsAnalyzer:
    def __init__(self):
        self.database_url = os.getenv('DATABASE_URL')
        if not self.database_url:
            raise ValueError("DATABASE_URL environment variable is required")
        
        self.engine = create_engine(self.database_url)
        print("📊 Connected to database for analysis")
    
    def load_data_from_database(self):
        """Load all metrics data from the database"""
        print("📥 Loading data from database...")
        
        # Load metrics with session info
        metrics_query = """
        SELECT 
            m.*,
            s.participant_id,
            s.start_time as session_start,
            s.duration_ms as session_duration
        FROM metrics m
        JOIN sessions s ON m.session_id = s.id
        ORDER BY m.timestamp_recorded DESC
        """
        
        # Load conversations
        conversations_query = """
        SELECT 
            c.*,
            s.participant_id
        FROM conversations c
        JOIN sessions s ON c.session_id = s.id
        ORDER BY c.timestamp_started DESC
        """
        
        # Load errors
        errors_query = """
        SELECT 
            e.*,
            s.participant_id
        FROM errors e
        LEFT JOIN sessions s ON e.session_id = s.id
        ORDER BY e.timestamp_occurred DESC
        """
        
        # Load session summary
        sessions_query = """
        SELECT * FROM metrics_summary
        ORDER BY start_time DESC
        """
        
        try:
            self.metrics_df = pd.read_sql(metrics_query, self.engine)
            self.conversations_df = pd.read_sql(conversations_query, self.engine)
            self.errors_df = pd.read_sql(errors_query, self.engine)
            self.sessions_df = pd.read_sql(sessions_query, self.engine)
            
            print(f"✅ Loaded {len(self.metrics_df)} metrics records")
            print(f"✅ Loaded {len(self.conversations_df)} conversation records")
            print(f"✅ Loaded {len(self.errors_df)} error records")
            print(f"✅ Loaded {len(self.sessions_df)} session records")
            
        except Exception as e:
            print(f"❌ Failed to load data from database: {e}")
            raise
    
    def analyze_performance_trends(self):
        """Analyze performance trends over time"""
        print("\n📈 PERFORMANCE TRENDS ANALYSIS")
        print("=" * 50)
        
        if self.conversations_df.empty:
            print("❌ No conversation data available")
            return
        
        # Convert timestamps
        self.conversations_df['timestamp_started'] = pd.to_datetime(self.conversations_df['timestamp_started'])
        
        # Group by hour for trend analysis
        hourly_stats = self.conversations_df.set_index('timestamp_started').resample('H').agg({
            'total_pipeline_latency_ms': ['mean', 'count', 'std'],
            'stt_latency_ms': 'mean',
            'llm_latency_ms': 'mean',
            'tts_latency_ms': 'mean'
        }).round(2)
        
        # Flatten column names
        hourly_stats.columns = ['_'.join(col).strip() for col in hourly_stats.columns]
        hourly_stats = hourly_stats.dropna()
        
        if not hourly_stats.empty:
            print(f"📊 Hourly Performance Summary (Last {len(hourly_stats)} hours):")
            print(f"Average Total Latency: {hourly_stats['total_pipeline_latency_ms_mean'].mean():.1f}ms")
            print(f"Peak Hour Latency: {hourly_stats['total_pipeline_latency_ms_mean'].max():.1f}ms")
            print(f"Best Hour Latency: {hourly_stats['total_pipeline_latency_ms_mean'].min():.1f}ms")
            print(f"Total Interactions: {hourly_stats['total_pipeline_latency_ms_count'].sum():.0f}")
            
            # Identify peak performance hours
            best_hour = hourly_stats['total_pipeline_latency_ms_mean'].idxmin()
            worst_hour = hourly_stats['total_pipeline_latency_ms_mean'].idxmax()
            
            print(f"\n🏆 Best Performance: {best_hour.strftime('%Y-%m-%d %H:00')} ({hourly_stats.loc[best_hour, 'total_pipeline_latency_ms_mean']:.1f}ms)")
            print(f"⚠️ Worst Performance: {worst_hour.strftime('%Y-%m-%d %H:00')} ({hourly_stats.loc[worst_hour, 'total_pipeline_latency_ms_mean']:.1f}ms)")
    
    def analyze_user_patterns(self):
        """Analyze patterns by user/participant"""
        print("\n👥 USER PERFORMANCE ANALYSIS")
        print("=" * 50)
        
        if self.sessions_df.empty:
            print("❌ No session data available")
            return
        
        # User performance summary
        user_stats = self.sessions_df.groupby('participant_id').agg({
            'total_conversations': 'sum',
            'avg_total_latency': 'mean',
            'avg_stt_latency': 'mean',
            'avg_llm_latency': 'mean',
            'avg_tts_latency': 'mean',
            'error_count': 'sum',
            'success_rate': 'mean'
        }).round(2)
        
        user_stats = user_stats.sort_values('avg_total_latency')
        
        print("📊 User Performance Ranking (by average latency):")
        for i, (user, stats) in enumerate(user_stats.iterrows(), 1):
            status = "🏆" if i <= 3 else "👍" if i <= len(user_stats) // 2 else "⚠️"
            print(f"{status} {i}. {user}:")
            print(f"   Avg Latency: {stats['avg_total_latency']:.1f}ms")
            print(f"   Conversations: {stats['total_conversations']:.0f}")
            print(f"   Success Rate: {stats['success_rate']:.1f}%")
            print(f"   Errors: {stats['error_count']:.0f}")
            print()
    
    def analyze_error_patterns(self):
        """Analyze error patterns and frequencies"""
        print("\n❌ ERROR ANALYSIS")
        print("=" * 50)
        
        if self.errors_df.empty:
            print("✅ No errors found in the database!")
            return
        
        # Error frequency by type
        error_counts = self.errors_df['error_type'].value_counts()
        
        print("📊 Error Frequency by Type:")
        for error_type, count in error_counts.items():
            percentage = (count / len(self.errors_df)) * 100
            print(f"  {error_type}: {count} ({percentage:.1f}%)")
        
        # Recent error trends
        self.errors_df['timestamp_occurred'] = pd.to_datetime(self.errors_df['timestamp_occurred'])
        recent_errors = self.errors_df[
            self.errors_df['timestamp_occurred'] > (datetime.now() - timedelta(hours=24))
        ]
        
        print(f"\n🕐 Errors in Last 24 Hours: {len(recent_errors)}")
        
        if not recent_errors.empty:
            recent_error_types = recent_errors['error_type'].value_counts()
            print("Recent Error Breakdown:")
            for error_type, count in recent_error_types.items():
                print(f"  {error_type}: {count}")
    
    def identify_bottlenecks(self):
        """Identify system bottlenecks using database data"""
        print("\n🔍 BOTTLENECK IDENTIFICATION")
        print("=" * 50)
        
        if self.conversations_df.empty:
            print("❌ No conversation data available")
            return
        
        # Calculate average latencies by component
        avg_latencies = {
            'STT': self.conversations_df['stt_latency_ms'].mean(),
            'LLM': self.conversations_df['llm_latency_ms'].mean(),
            'TTS': self.conversations_df['tts_latency_ms'].mean()
        }
        
        # Sort by latency (highest first)
        sorted_components = sorted(avg_latencies.items(), key=lambda x: x[1], reverse=True)
        
        print("📊 Component Performance Ranking (slowest first):")
        for i, (component, avg_latency) in enumerate(sorted_components, 1):
            status = "🔴" if i == 1 else "🟡" if i == 2 else "🟢"
            print(f"{status} {i}. {component}: {avg_latency:.1f}ms average")
        
        # Bottleneck recommendations
        slowest_component = sorted_components[0][0]
        print(f"\n💡 PRIMARY BOTTLENECK: {slowest_component}")
        
        recommendations = {
            'STT': [
                "• Consider using a faster STT model (e.g., Deepgram Nova-2)",
                "• Optimize audio preprocessing and encoding",
                "• Check network latency to STT service",
                "• Implement audio streaming for real-time processing"
            ],
            'LLM': [
                "• Use a smaller, faster model (e.g., GPT-4o-mini vs GPT-4)",
                "• Implement response streaming to reduce perceived latency",
                "• Reduce context window size and conversation history",
                "• Consider local LLM deployment for lower latency"
            ],
            'TTS': [
                "• Use a faster TTS model (e.g., ElevenLabs Turbo)",
                "• Implement audio streaming for immediate playback",
                "• Optimize voice settings for speed vs quality",
                "• Consider edge TTS deployment"
            ]
        }
        
        print("🛠️ OPTIMIZATION RECOMMENDATIONS:")
        for rec in recommendations.get(slowest_component, []):
            print(f"  {rec}")
    
    def generate_performance_report(self):
        """Generate comprehensive performance report"""
        print("\n📋 COMPREHENSIVE PERFORMANCE REPORT")
        print("=" * 60)
        
        # Overall statistics
        total_conversations = len(self.conversations_df)
        total_errors = len(self.errors_df)
        success_rate = ((total_conversations - total_errors) / total_conversations * 100) if total_conversations > 0 else 0
        
        if not self.conversations_df.empty:
            avg_total_latency = self.conversations_df['total_pipeline_latency_ms'].mean()
            median_latency = self.conversations_df['total_pipeline_latency_ms'].median()
            p95_latency = self.conversations_df['total_pipeline_latency_ms'].quantile(0.95)
            under_2s = (self.conversations_df['total_pipeline_latency_ms'] < 2000).sum()
            under_2s_percent = (under_2s / total_conversations) * 100
        else:
            avg_total_latency = median_latency = p95_latency = 0
            under_2s = under_2s_percent = 0
        
        print(f"📊 OVERALL METRICS:")
        print(f"  Total Conversations: {total_conversations:,}")
        print(f"  Total Errors: {total_errors:,}")
        print(f"  Success Rate: {success_rate:.1f}%")
        print(f"  Average Latency: {avg_total_latency:.1f}ms")
        print(f"  Median Latency: {median_latency:.1f}ms")
        print(f"  95th Percentile: {p95_latency:.1f}ms")
        print(f"  Under 2s Target: {under_2s:,}/{total_conversations:,} ({under_2s_percent:.1f}%)")
        
        # Performance grading
        if avg_total_latency < 1000 and under_2s_percent > 95:
            grade = "A+ (Exceptional)"
            emoji = "🏆"
        elif avg_total_latency < 1500 and under_2s_percent > 90:
            grade = "A (Excellent)"
            emoji = "🌟"
        elif avg_total_latency < 2000 and under_2s_percent > 80:
            grade = "B (Good)"
            emoji = "👍"
        elif avg_total_latency < 2500 and under_2s_percent > 70:
            grade = "C (Acceptable)"
            emoji = "⚠️"
        else:
            grade = "D (Needs Improvement)"
            emoji = "🔧"
        
        print(f"\n🎯 PERFORMANCE GRADE: {emoji} {grade}")
        
        # Active users
        active_users = len(self.sessions_df['participant_id'].unique())
        avg_session_duration = self.sessions_df['session_duration_ms'].mean() / 1000 if not self.sessions_df.empty else 0
        
        print(f"\n👥 USER ENGAGEMENT:")
        print(f"  Active Users: {active_users}")
        print(f"  Average Session Duration: {avg_session_duration:.1f}s")
        print(f"  Conversations per User: {total_conversations / active_users:.1f}" if active_users > 0 else "  Conversations per User: 0")
    
    def create_database_visualizations(self):
        """Create visualizations from database data"""
        print("\n📊 Creating database visualizations...")
        
        if self.conversations_df.empty:
            print("❌ No data available for visualization")
            return
        
        # Set up the plotting style
        plt.style.use('seaborn-v0_8')
        fig, axes = plt.subplots(2, 3, figsize=(20, 12))
        fig.suptitle('AI Voice Agent Database Analytics', fontsize=16, fontweight='bold')
        
        # 1. Latency Distribution
        latencies = self.conversations_df['total_pipeline_latency_ms'].dropna()
        axes[0, 0].hist(latencies, bins=30, alpha=0.7, color='skyblue', edgecolor='black')
        axes[0, 0].axvline(2000, color='red', linestyle='--', label='2s Target')
        axes[0, 0].set_title('Total Latency Distribution')
        axes[0, 0].set_xlabel('Latency (ms)')
        axes[0, 0].set_ylabel('Frequency')
        axes[0, 0].legend()
        
        # 2. Component Latency Comparison
        component_data = {
            'STT': self.conversations_df['stt_latency_ms'].mean(),
            'LLM': self.conversations_df['llm_latency_ms'].mean(),
            'TTS': self.conversations_df['tts_latency_ms'].mean()
        }
        
        bars = axes[0, 1].bar(component_data.keys(), component_data.values(), 
                             color=['lightcoral', 'lightgreen', 'lightblue'])
        axes[0, 1].set_title('Average Component Latencies')
        axes[0, 1].set_ylabel('Latency (ms)')
        
        for bar, value in zip(bars, component_data.values()):
            axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10,
                           f'{value:.0f}ms', ha='center', va='bottom')
        
        # 3. Performance by User
        if not self.sessions_df.empty:
            user_performance = self.sessions_df.groupby('participant_id')['avg_total_latency'].mean().sort_values()
            user_performance.plot(kind='bar', ax=axes[0, 2], color='orange', alpha=0.7)
            axes[0, 2].set_title('Average Latency by User')
            axes[0, 2].set_xlabel('Participant')
            axes[0, 2].set_ylabel('Latency (ms)')
            axes[0, 2].tick_params(axis='x', rotation=45)
        
        # 4. Error Distribution
        if not self.errors_df.empty:
            error_counts = self.errors_df['error_type'].value_counts()
            axes[1, 0].pie(error_counts.values, labels=error_counts.index, autopct='%1.1f%%')
            axes[1, 0].set_title('Error Distribution by Type')
        else:
            axes[1, 0].text(0.5, 0.5, 'No Errors Found!', ha='center', va='center', 
                           transform=axes[1, 0].transAxes, fontsize=14, color='green')
            axes[1, 0].set_title('Error Distribution')
        
        # 5. Performance Over Time
        if 'timestamp_started' in self.conversations_df.columns:
            self.conversations_df['timestamp_started'] = pd.to_datetime(self.conversations_df['timestamp_started'])
            time_data = self.conversations_df.set_index('timestamp_started').resample('H')['total_pipeline_latency_ms'].mean()
            
            if not time_data.empty:
                time_data.plot(ax=axes[1, 1], marker='o', markersize=4)
                axes[1, 1].axhline(2000, color='red', linestyle='--', label='2s Target')
                axes[1, 1].set_title('Latency Trend Over Time')
                axes[1, 1].set_xlabel('Time')
                axes[1, 1].set_ylabel('Latency (ms)')
                axes[1, 1].legend()
                axes[1, 1].tick_params(axis='x', rotation=45)
        
        # 6. Performance Summary Box
        axes[1, 2].axis('off')
        
        total_conversations = len(self.conversations_df)
        avg_latency = self.conversations_df['total_pipeline_latency_ms'].mean()
        under_2s = (self.conversations_df['total_pipeline_latency_ms'] < 2000).sum()
        success_rate = ((total_conversations - len(self.errors_df)) / total_conversations * 100) if total_conversations > 0 else 0
        
        summary_text = f"""
Database Performance Summary

Total Conversations: {total_conversations:,}
Average Latency: {avg_latency:.1f}ms
Median Latency: {self.conversations_df['total_pipeline_latency_ms'].median():.1f}ms
95th Percentile: {self.conversations_df['total_pipeline_latency_ms'].quantile(0.95):.1f}ms

Target Performance (< 2s):
{under_2s:,}/{total_conversations:,} conversations
({under_2s/total_conversations*100:.1f}%)

Success Rate: {success_rate:.1f}%
Total Errors: {len(self.errors_df):,}

Active Users: {len(self.sessions_df['participant_id'].unique())}
        """
        
        axes[1, 2].text(0.1, 0.9, summary_text, transform=axes[1, 2].transAxes,
                       fontsize=11, verticalalignment='top', fontfamily='monospace',
                       bbox=dict(boxstyle='round', facecolor='lightgray', alpha=0.8))
        
        plt.tight_layout()
        
        # Save the plot
        output_path = f'database_analysis_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"📊 Database visualization saved to: {output_path}")
        
        # Show the plot
        plt.show()
    
    def export_analysis_report(self):
        """Export comprehensive analysis to Excel"""
        print("\n📄 Exporting comprehensive analysis report...")
        
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment
            
            wb = Workbook()
            
            # Summary Sheet
            ws_summary = wb.active
            ws_summary.title = "Performance Summary"
            
            # Add headers and data
            headers = ['Metric', 'Value', 'Status']
            for col, header in enumerate(headers, 1):
                cell = ws_summary.cell(row=1, column=col, value=header)
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            
            # Add summary data
            total_conversations = len(self.conversations_df)
            avg_latency = self.conversations_df['total_pipeline_latency_ms'].mean() if not self.conversations_df.empty else 0
            under_2s_percent = (self.conversations_df['total_pipeline_latency_ms'] < 2000).sum() / total_conversations * 100 if total_conversations > 0 else 0
            success_rate = ((total_conversations - len(self.errors_df)) / total_conversations * 100) if total_conversations > 0 else 0
            
            summary_data = [
                ['Total Conversations', f'{total_conversations:,}', ''],
                ['Average Latency (ms)', f'{avg_latency:.1f}', '✅' if avg_latency < 1500 else '⚠️'],
                ['Under 2s Target (%)', f'{under_2s_percent:.1f}%', '✅' if under_2s_percent > 80 else '⚠️'],
                ['Success Rate (%)', f'{success_rate:.1f}%', '✅' if success_rate > 95 else '⚠️'],
                ['Total Errors', f'{len(self.errors_df):,}', '✅' if len(self.errors_df) < 10 else '⚠️'],
                ['Active Users', f'{len(self.sessions_df["participant_id"].unique()):,}', '']
            ]
            
            for row, data in enumerate(summary_data, 2):
                for col, value in enumerate(data, 1):
                    ws_summary.cell(row=row, column=col, value=value)
            
            # Detailed Metrics Sheet
            if not self.conversations_df.empty:
                ws_details = wb.create_sheet("Detailed Metrics")
                
                # Convert conversations dataframe to Excel
                for col, column_name in enumerate(self.conversations_df.columns, 1):
                    cell = ws_details.cell(row=1, column=col, value=column_name)
                    cell.font = Font(bold=True)
                
                for row, (_, data) in enumerate(self.conversations_df.iterrows(), 2):
                    for col, value in enumerate(data, 1):
                        ws_details.cell(row=row, column=col, value=str(value))
            
            # Error Analysis Sheet
            if not self.errors_df.empty:
                ws_errors = wb.create_sheet("Error Analysis")
                
                for col, column_name in enumerate(self.errors_df.columns, 1):
                    cell = ws_errors.cell(row=1, column=col, value=column_name)
                    cell.font = Font(bold=True)
                
                for row, (_, data) in enumerate(self.errors_df.iterrows(), 2):
                    for col, value in enumerate(data, 1):
                        ws_errors.cell(row=row, column=col, value=str(value))
            
            # Save workbook
            filename = f'database_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            wb.save(filename)
            print(f"📊 Analysis report exported to: {filename}")
            
        except ImportError:
            print("⚠️ openpyxl not available, using pandas export instead")
            
            # Fallback to pandas export
            filename = f'database_analysis_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
            with pd.ExcelWriter(filename, engine='openpyxl') as writer:
                if not self.conversations_df.empty:
                    self.conversations_df.to_excel(writer, sheet_name='Conversations', index=False)
                if not self.errors_df.empty:
                    self.errors_df.to_excel(writer, sheet_name='Errors', index=False)
                if not self.sessions_df.empty:
                    self.sessions_df.to_excel(writer, sheet_name='Sessions', index=False)
            
            print(f"📊 Analysis report exported to: {filename}")

def main():
    """Main database analysis function"""
    print("🚀 Starting AI Voice Agent Database Analysis")
    print("=" * 60)
    
    try:
        analyzer = DatabaseMetricsAnalyzer()
        
        # Load data from database
        analyzer.load_data_from_database()
        
        # Run all analyses
        analyzer.analyze_performance_trends()
        analyzer.analyze_user_patterns()
        analyzer.analyze_error_patterns()
        analyzer.identify_bottlenecks()
        analyzer.generate_performance_report()
        analyzer.create_database_visualizations()
        analyzer.export_analysis_report()
        
        print("\n✅ Database analysis complete!")
        print("\n💡 Next Steps:")
        print("  1. Review the performance report above")
        print("  2. Check the generated visualizations")
        print("  3. Examine the exported Excel report")
        print("  4. Implement recommended optimizations")
        print("  5. Monitor improvements over time")
        
    except Exception as e:
        print(f"❌ Database analysis failed: {e}")
        raise

if __name__ == "__main__":
    main()
