-- Insert dummy data for testing and demonstration

-- Insert dummy sessions
INSERT INTO sessions (id, participant_id, start_time, end_time, duration_ms, total_interactions, average_latency, error_count) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'user_alice', NOW() - INTERVAL '2 hours', NOW() - INTERVAL '1 hour 45 minutes', 900000, 15, 1250.5, 1),
('550e8400-e29b-41d4-a716-446655440002', 'user_bob', NOW() - INTERVAL '1 hour 30 minutes', NOW() - INTERVAL '1 hour', 1800000, 25, 980.2, 0),
('550e8400-e29b-41d4-a716-446655440003', 'user_charlie', NOW() - INTERVAL '45 minutes', NOW() - INTERVAL '30 minutes', 900000, 12, 1450.8, 2),
('550e8400-e29b-41d4-a716-446655440004', 'user_diana', NOW() - INTERVAL '30 minutes', NOW() - INTERVAL '15 minutes', 900000, 18, 1100.3, 0),
('550e8400-e29b-41d4-a716-446655440005', 'user_eve', NOW() - INTERVAL '15 minutes', NOW() - INTERVAL '5 minutes', 600000, 8, 1350.7, 1);

-- Insert dummy conversations
INSERT INTO conversations (session_id, user_input, ai_response, total_pipeline_latency_ms, stt_latency_ms, llm_latency_ms, tts_latency_ms, timestamp_started, timestamp_completed) VALUES
-- Alice's session
('550e8400-e29b-41d4-a716-446655440001', 'Hello, how are you today?', 'Hello! I''m doing great, thank you for asking. How can I help you today?', 1250, 180, 650, 420, NOW() - INTERVAL '2 hours', NOW() - INTERVAL '2 hours' + INTERVAL '1.25 seconds'),
('550e8400-e29b-41d4-a716-446655440001', 'What''s the weather like?', 'I don''t have access to current weather data, but I''d be happy to help you find weather information!', 1180, 165, 580, 435, NOW() - INTERVAL '1 hour 58 minutes', NOW() - INTERVAL '1 hour 58 minutes' + INTERVAL '1.18 seconds'),
('550e8400-e29b-41d4-a716-446655440001', 'Tell me a joke', 'Why don''t scientists trust atoms? Because they make up everything!', 950, 140, 480, 330, NOW() - INTERVAL '1 hour 55 minutes', NOW() - INTERVAL '1 hour 55 minutes' + INTERVAL '0.95 seconds'),

-- Bob's session (better performance)
('550e8400-e29b-41d4-a716-446655440002', 'Can you help me with math?', 'I''d be happy to help you with math problems. What do you need help with?', 890, 120, 450, 320, NOW() - INTERVAL '1 hour 25 minutes', NOW() - INTERVAL '1 hour 25 minutes' + INTERVAL '0.89 seconds'),
('550e8400-e29b-41d4-a716-446655440002', 'What is 25 times 17?', 'Let me calculate that for you. 25 times 17 equals 425.', 780, 110, 380, 290, NOW() - INTERVAL '1 hour 20 minutes', NOW() - INTERVAL '1 hour 20 minutes' + INTERVAL '0.78 seconds'),
('550e8400-e29b-41d4-a716-446655440002', 'Explain quantum physics simply', 'Quantum physics is the study of very tiny particles that behave in strange ways, like being in multiple places at once until observed.', 1150, 135, 620, 395, NOW() - INTERVAL '1 hour 15 minutes', NOW() - INTERVAL '1 hour 15 minutes' + INTERVAL '1.15 seconds'),

-- Charlie's session (some issues)
('550e8400-e29b-41d4-a716-446655440003', 'Hello there', 'Hi! Nice to meet you. How can I assist you today?', 1650, 220, 850, 580, NOW() - INTERVAL '40 minutes', NOW() - INTERVAL '40 minutes' + INTERVAL '1.65 seconds'),
('550e8400-e29b-41d4-a716-446655440003', 'What time is it?', 'I don''t have access to the current time, but you can check your device''s clock for the accurate time.', 1380, 190, 720, 470, NOW() - INTERVAL '35 minutes', NOW() - INTERVAL '35 minutes' + INTERVAL '1.38 seconds'),

-- Diana's session (excellent performance)
('550e8400-e29b-41d4-a716-446655440004', 'Good morning!', 'Good morning! I hope you''re having a wonderful day. What can I help you with?', 850, 95, 420, 335, NOW() - INTERVAL '25 minutes', NOW() - INTERVAL '25 minutes' + INTERVAL '0.85 seconds'),
('550e8400-e29b-41d4-a716-446655440004', 'Recommend a book', 'I''d recommend "The Midnight Library" by Matt Haig - it''s a thought-provoking novel about life''s possibilities.', 920, 105, 480, 335, NOW() - INTERVAL '20 minutes', NOW() - INTERVAL '20 minutes' + INTERVAL '0.92 seconds'),

-- Eve's session
('550e8400-e29b-41d4-a716-446655440005', 'How do I cook pasta?', 'To cook pasta: boil salted water, add pasta, cook for package time, drain, and serve with your favorite sauce!', 1420, 175, 780, 465, NOW() - INTERVAL '12 minutes', NOW() - INTERVAL '12 minutes' + INTERVAL '1.42 seconds');

-- Insert detailed metrics for each conversation
INSERT INTO metrics (session_id, metric_type, latency_ms, ttft_ms, ttfb_ms, timestamp_recorded, additional_data) VALUES
-- Alice's metrics
('550e8400-e29b-41d4-a716-446655440001', 'stt_latency', 180, NULL, NULL, NOW() - INTERVAL '2 hours', '{"confidence": 0.95, "language": "en-US"}'),
('550e8400-e29b-41d4-a716-446655440001', 'llm_latency', 650, 120, NULL, NOW() - INTERVAL '2 hours', '{"model": "gpt-4o-mini", "tokens": 45}'),
('550e8400-e29b-41d4-a716-446655440001', 'tts_latency', 420, NULL, 85, NOW() - INTERVAL '2 hours', '{"voice_id": "pNInz6obpgDQGcFmaJgB", "characters": 67}'),
('550e8400-e29b-41d4-a716-446655440001', 'total_latency', 1250, NULL, NULL, NOW() - INTERVAL '2 hours', '{"pipeline_complete": true}'),

-- Bob's metrics (better performance)
('550e8400-e29b-41d4-a716-446655440002', 'stt_latency', 120, NULL, NULL, NOW() - INTERVAL '1 hour 25 minutes', '{"confidence": 0.98, "language": "en-US"}'),
('550e8400-e29b-41d4-a716-446655440002', 'llm_latency', 450, 95, NULL, NOW() - INTERVAL '1 hour 25 minutes', '{"model": "gpt-4o-mini", "tokens": 38}'),
('550e8400-e29b-41d4-a716-446655440002', 'tts_latency', 320, NULL, 65, NOW() - INTERVAL '1 hour 25 minutes', '{"voice_id": "pNInz6obpgDQGcFmaJgB", "characters": 52}'),
('550e8400-e29b-41d4-a716-446655440002', 'total_latency', 890, NULL, NULL, NOW() - INTERVAL '1 hour 25 minutes', '{"pipeline_complete": true}'),

-- Charlie's metrics (some issues)
('550e8400-e29b-41d4-a716-446655440003', 'stt_latency', 220, NULL, NULL, NOW() - INTERVAL '40 minutes', '{"confidence": 0.87, "language": "en-US"}'),
('550e8400-e29b-41d4-a716-446655440003', 'llm_latency', 850, 180, NULL, NOW() - INTERVAL '40 minutes', '{"model": "gpt-4o-mini", "tokens": 28}'),
('550e8400-e29b-41d4-a716-446655440003', 'tts_latency', 580, NULL, 125, NOW() - INTERVAL '40 minutes', '{"voice_id": "pNInz6obpgDQGcFmaJgB", "characters": 41}'),
('550e8400-e29b-41d4-a716-446655440003', 'total_latency', 1650, NULL, NULL, NOW() - INTERVAL '40 minutes', '{"pipeline_complete": true}'),

-- Diana's metrics (excellent)
('550e8400-e29b-41d4-a716-446655440004', 'stt_latency', 95, NULL, NULL, NOW() - INTERVAL '25 minutes', '{"confidence": 0.99, "language": "en-US"}'),
('550e8400-e29b-41d4-a716-446655440004', 'llm_latency', 420, 75, NULL, NOW() - INTERVAL '25 minutes', '{"model": "gpt-4o-mini", "tokens": 42}'),
('550e8400-e29b-41d4-a716-446655440004', 'tts_latency', 335, NULL, 55, NOW() - INTERVAL '25 minutes', '{"voice_id": "pNInz6obpgDQGcFmaJgB", "characters": 58}'),
('550e8400-e29b-41d4-a716-446655440004', 'total_latency', 850, NULL, NULL, NOW() - INTERVAL '25 minutes', '{"pipeline_complete": true}'),

-- Eve's metrics
('550e8400-e29b-41d4-a716-446655440005', 'stt_latency', 175, NULL, NULL, NOW() - INTERVAL '12 minutes', '{"confidence": 0.92, "language": "en-US"}'),
('550e8400-e29b-41d4-a716-446655440005', 'llm_latency', 780, 145, NULL, NOW() - INTERVAL '12 minutes', '{"model": "gpt-4o-mini", "tokens": 55}'),
('550e8400-e29b-41d4-a716-446655440005', 'tts_latency', 465, NULL, 95, NOW() - INTERVAL '12 minutes', '{"voice_id": "pNInz6obpgDQGcFmaJgB", "characters": 72}'),
('550e8400-e29b-41d4-a716-446655440005', 'total_latency', 1420, NULL, NULL, NOW() - INTERVAL '12 minutes', '{"pipeline_complete": true}');

-- Insert some error records
INSERT INTO errors (session_id, error_type, error_message, timestamp_occurred) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'TTS_TIMEOUT', 'ElevenLabs API timeout after 5 seconds', NOW() - INTERVAL '1 hour 50 minutes'),
('550e8400-e29b-41d4-a716-446655440003', 'STT_LOW_CONFIDENCE', 'Speech recognition confidence below threshold (0.7)', NOW() - INTERVAL '38 minutes'),
('550e8400-e29b-41d4-a716-446655440003', 'LLM_RATE_LIMIT', 'OpenAI API rate limit exceeded', NOW() - INTERVAL '36 minutes'),
('550e8400-e29b-41d4-a716-446655440005', 'NETWORK_ERROR', 'Connection timeout to Deepgram service', NOW() - INTERVAL '10 minutes');

-- Add some additional metrics for variety
INSERT INTO metrics (session_id, metric_type, latency_ms, timestamp_recorded, additional_data) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'eou_delay', 250, NOW() - INTERVAL '2 hours', '{"silence_duration": 800}'),
('550e8400-e29b-41d4-a716-446655440002', 'eou_delay', 180, NOW() - INTERVAL '1 hour 25 minutes', '{"silence_duration": 600}'),
('550e8400-e29b-41d4-a716-446655440003', 'eou_delay', 320, NOW() - INTERVAL '40 minutes', '{"silence_duration": 1200}'),
('550e8400-e29b-41d4-a716-446655440004', 'eou_delay', 150, NOW() - INTERVAL '25 minutes', '{"silence_duration": 500}'),
('550e8400-e29b-41d4-a716-446655440005', 'eou_delay', 280, NOW() - INTERVAL '12 minutes', '{"silence_duration": 900}');
