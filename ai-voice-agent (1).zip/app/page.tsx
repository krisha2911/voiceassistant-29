"use client"

import  from "../src/agent"

export default function SyntheticV0PageForDeployment() {
  return < />
}