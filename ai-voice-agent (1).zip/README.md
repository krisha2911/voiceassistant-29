# AI Voice Agent with Livekit

A real-time AI voice agent implementation using Livekit, featuring Speech-to-Text, Large Language Model processing, and Text-to-Speech capabilities with comprehensive metrics logging and performance optimization.

## Features

- **Real-time Voice Pipeline**: STT → LLM → TTS flow with WebSocket communication
- **Multiple Service Integrations**: 
  - STT: Deepgram (with Whisper fallback)
  - LLM: OpenAI GPT-4 / Together AI
  - TTS: ElevenLabs / Cartesia
- **Performance Monitoring**: Comprehensive metrics logging with Excel export
- **Latency Optimization**: Sub-2s response time targeting
- **Interruption Handling**: Context buffering and resumption
- **Testing Suite**: Automated testing with performance analysis

## Quick Start

### 1. Environment Setup

\`\`\`bash
# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your API keys
\`\`\`

### 2. Configure API Keys

Add your API keys to `.env`:

\`\`\`env
# Livekit
LIVEKIT_URL=wss://your-livekit-server.com
LIVEKIT_API_KEY=your-api-key
LIVEKIT_API_SECRET=your-api-secret

# Services
DEEPGRAM_API_KEY=your-deepgram-key
OPENAI_API_KEY=your-openai-key
ELEVENLABS_API_KEY=your-elevenlabs-key
\`\`\`

### 3. Run the Agent

\`\`\`bash
# Start the agent
npm start

# Or run in development mode
npm run dev
\`\`\`

### 4. Test the Pipeline

\`\`\`bash
# Run automated tests
npm run test

# Analyze performance metrics
npm run metrics
\`\`\`

## Architecture

### Core Components

1. **STTService** (`src/services/stt.js`)
   - Deepgram integration for speech-to-text
   - Real-time streaming with interim results
   - Latency tracking and optimization

2. **LLMService** (`src/services/llm.js`)
   - OpenAI GPT-4 integration
   - Streaming response generation
   - Conversation context management

3. **TTSService** (`src/services/tts.js`)
   - ElevenLabs text-to-speech
   - Streaming audio generation
   - Voice customization options

4. **SessionHandler** (`src/handlers/session.js`)
   - Manages STT → LLM → TTS pipeline
   - Handles interruptions and context
   - Coordinates metrics logging

5. **MetricsLogger** (`src/utils/metrics.js`)
   - Comprehensive performance tracking
   - Excel export functionality
   - Real-time latency monitoring

### Pipeline Flow

\`\`\`
Audio Input → STT → LLM → TTS → Audio Output
     ↓         ↓     ↓     ↓         ↓
   Metrics → Metrics → Metrics → Metrics → Analysis
\`\`\`

## Performance Targets

- **Total Latency**: < 2000ms (target: < 1500ms)
- **STT Latency**: < 300ms
- **LLM TTFT**: < 500ms (Time to First Token)
- **TTS TTFB**: < 200ms (Time to First Byte)
- **Success Rate**: > 95%

## Metrics & Analytics

### Tracked Metrics

- **EOU Delay**: End of Utterance detection time
- **TTFT**: Time to First Token (LLM)
- **TTFB**: Time to First Byte (TTS)
- **Total Latency**: Complete pipeline response time
- **Error Rates**: Service failures and recovery

### Analysis Tools

The Python analysis script (`scripts/analyze_metrics.py`) provides:

- Latency distribution analysis
- Bottleneck identification
- Performance trend visualization
- Optimization recommendations
- Automated reporting

## Optimization Strategies

### Latency Reduction

1. **Streaming Implementation**
   - LLM response streaming
   - TTS audio streaming
   - Parallel processing where possible

2. **Model Optimization**
   - Faster STT models (Nova-2)
   - Efficient LLM models (GPT-4o-mini)
   - Optimized TTS settings

3. **Infrastructure**
   - Edge deployment
   - CDN for audio delivery
   - Connection pooling

### Quality Improvements

1. **Context Management**
   - Conversation history optimization
   - Smart context truncation
   - Memory-efficient storage

2. **Error Handling**
   - Graceful degradation
   - Service fallbacks
   - Retry mechanisms

## Testing

### Automated Testing

\`\`\`bash
# Run full test suite
npm run test

# Test specific components
node src/test-agent.js
\`\`\`

### Manual Testing

Use the Livekit Agent Playground:
1. Deploy agent to Livekit server
2. Connect via playground interface
3. Test voice interactions
4. Monitor real-time metrics

## Deployment

### Local Development

\`\`\`bash
npm run dev
\`\`\`

### Production Deployment

1. **Docker Deployment**
\`\`\`bash
docker build -t ai-voice-agent .
docker run -p 3000:3000 ai-voice-agent
\`\`\`

2. **Livekit Cloud**
- Deploy to Livekit Cloud
- Configure webhooks
- Set up monitoring

## Troubleshooting

### Common Issues

1. **High Latency**
   - Check network connectivity
   - Verify API key limits
   - Review service regions

2. **Audio Quality**
   - Adjust TTS voice settings
   - Check audio encoding
   - Verify sample rates

3. **Connection Issues**
   - Validate Livekit configuration
   - Check firewall settings
   - Verify WebSocket support

### Debug Mode

Enable detailed logging:
\`\`\`bash
DEBUG=* npm start
\`\`\`

## Contributing

1. Fork the repository
2. Create feature branch
3. Add tests for new features
4. Ensure metrics tracking
5. Submit pull request

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
1. Check the troubleshooting guide
2. Review Livekit documentation
3. Open GitHub issue with metrics data

## Database Setup

### Using Neon Database

1. **Create a Neon Database**
   \`\`\`bash
   # Sign up at https://neon.tech
   # Create a new database project
   # Copy the connection string
   \`\`\`

2. **Configure Environment**
   \`\`\`bash
   # Add to your .env file
   DATABASE_URL=postgresql://username:password@hostname:5432/database_name
   \`\`\`

3. **Initialize Database Schema**
   \`\`\`bash
   # Run the SQL scripts to create tables
   npm run test-db
   \`\`\`

### Database Features

- **Real-time Metrics Storage**: All performance metrics stored in PostgreSQL
- **Session Tracking**: Complete user session management
- **Error Logging**: Comprehensive error tracking and analysis
- **Performance Analytics**: Built-in views for metrics analysis
- **Data Export**: Excel export functionality for detailed analysis

### Database Testing

\`\`\`bash
# Test database connection and generate dummy data
npm run test-db

# Run Python analysis on database data
python scripts/database_analysis.py
\`\`\`

The database integration provides:
- Persistent metrics storage
- Real-time performance monitoring
- Historical trend analysis
- User behavior insights
- Error pattern identification
- Automated reporting
