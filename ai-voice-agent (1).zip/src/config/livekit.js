import { Room, RoomEvent } from "livekit-client"
import { AccessToken } from "livekit-server-sdk"

export class LivekitConfig {
  constructor() {
    this.serverUrl = process.env.LIVEKIT_URL
    this.apiKey = process.env.LIVEKIT_API_KEY
    this.apiSecret = process.env.LIVEKIT_API_SECRET
  }

  generateAccessToken(roomName, participantName, permissions = {}) {
    const at = new AccessToken(this.apiKey, this.apiSecret, {
      identity: participantName,
      ttl: "10m", // 10 minutes
    })

    at.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: permissions.canPublish || true,
      canSubscribe: permissions.canSubscribe || true,
      canPublishData: permissions.canPublishData || true,
    })

    return at.toJwt()
  }

  createRoomOptions() {
    return {
      adaptiveStream: true,
      dynacast: true,
      publishDefaults: {
        audioPreset: {
          maxBitrate: 64000,
          priority: "high",
        },
      },
    }
  }

  async connectToRoom(token, roomOptions = null) {
    const room = new Room(roomOptions || this.createRoomOptions())

    room.on(RoomEvent.Connected, () => {
      console.log("✅ Connected to Livekit room")
    })

    room.on(RoomEvent.Disconnected, (reason) => {
      console.log("❌ Disconnected from room:", reason)
    })

    room.on(RoomEvent.ParticipantConnected, (participant) => {
      console.log("👤 Participant joined:", participant.identity)
    })

    await room.connect(this.serverUrl, token)
    return room
  }
}
