import { createClient } from "@deepgram/sdk"
import { EventEmitter } from "events"

export class STTService extends EventEmitter {
  constructor() {
    super()
    this.deepgram = createClient(process.env.DEEPGRAM_API_KEY)
    this.connection = null
    this.isListening = false
  }

  async initialize() {
    console.log("🎤 Initializing Speech-to-Text service...")

    // Test connection
    try {
      const response = await this.deepgram.manage.getProjectBalances(process.env.DEEPGRAM_PROJECT_ID || "default")
      console.log("✅ Deepgram STT service initialized")
    } catch (error) {
      console.warn("⚠️ Deepgram connection test failed, but continuing...")
    }
  }

  async startListening(audioStream) {
    if (this.isListening) return

    const startTime = Date.now()

    this.connection = this.deepgram.listen.live({
      model: "nova-2",
      language: "en-US",
      smart_format: true,
      interim_results: true,
      endpointing: 300,
      utterance_end_ms: 1000,
    })

    this.connection.on("open", () => {
      console.log("🔊 STT connection opened")
      this.isListening = true
    })

    this.connection.on("Results", (data) => {
      const transcript = data.channel?.alternatives?.[0]?.transcript
      if (transcript) {
        const latency = Date.now() - startTime
        this.emit("transcript", {
          text: transcript,
          is_final: data.is_final,
          latency,
          timestamp: Date.now(),
        })
      }
    })

    this.connection.on("error", (error) => {
      console.error("❌ STT Error:", error)
      this.emit("error", error)
    })

    // Pipe audio stream to Deepgram
    audioStream.on("data", (chunk) => {
      if (this.connection && this.isListening) {
        this.connection.send(chunk)
      }
    })

    return this.connection
  }

  stopListening() {
    if (this.connection) {
      this.connection.finish()
      this.connection = null
      this.isListening = false
      console.log("🔇 STT stopped listening")
    }
  }
}
