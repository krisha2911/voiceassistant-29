import ElevenLabs from "elevenlabs"
import { EventEmitter } from "events"

export class TTSService extends EventEmitter {
  constructor() {
    super()
    this.elevenlabs = new ElevenLabs({
      apiKey: process.env.ELEVENLABS_API_KEY,
    })
    this.voiceId = process.env.ELEVENLABS_VOICE_ID || "pNInz6obpgDQGcFmaJgB" // Default voice
  }

  async initialize() {
    console.log("🔊 Initializing Text-to-Speech service...")

    try {
      // Test ElevenLabs connection by getting voices
      const voices = await this.elevenlabs.voices.getAll()
      console.log(`✅ ElevenLabs TTS initialized with ${voices.voices.length} voices available`)
    } catch (error) {
      console.warn("⚠️ ElevenLabs connection test failed:", error.message)
    }
  }

  async synthesizeSpeech(text, streaming = true) {
    const startTime = Date.now()

    try {
      if (streaming) {
        return await this.synthesizeStreaming(text, startTime)
      } else {
        return await this.synthesizeComplete(text, startTime)
      }
    } catch (error) {
      console.error("❌ TTS Error:", error)
      throw error
    }
  }

  async synthesizeStreaming(text, startTime) {
    const audioStream = await this.elevenlabs.generate({
      voice: this.voiceId,
      text,
      model_id: "eleven_turbo_v2",
      stream: true,
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75,
        style: 0.0,
        use_speaker_boost: true,
      },
    })

    let firstByteTime = null
    let audioBuffer = Buffer.alloc(0)

    return new Promise((resolve, reject) => {
      audioStream.on("data", (chunk) => {
        if (!firstByteTime) {
          firstByteTime = Date.now()
          const ttfb = firstByteTime - startTime // Time to First Byte
          this.emit("first_byte", { ttfb, timestamp: firstByteTime })
        }

        audioBuffer = Buffer.concat([audioBuffer, chunk])
        this.emit("audio_chunk", {
          chunk,
          timestamp: Date.now(),
        })
      })

      audioStream.on("end", () => {
        const totalLatency = Date.now() - startTime
        resolve({
          audio: audioBuffer,
          latency: totalLatency,
          ttfb: firstByteTime ? firstByteTime - startTime : null,
          timestamp: Date.now(),
        })
      })

      audioStream.on("error", reject)
    })
  }

  async synthesizeComplete(text, startTime) {
    const audioBuffer = await this.elevenlabs.generate({
      voice: this.voiceId,
      text,
      model_id: "eleven_turbo_v2",
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75,
        style: 0.0,
        use_speaker_boost: true,
      },
    })

    const latency = Date.now() - startTime

    return {
      audio: audioBuffer,
      latency,
      timestamp: Date.now(),
    }
  }
}
