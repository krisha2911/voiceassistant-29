import OpenAI from "openai"
import Together from "together-ai"
import { EventEmitter } from "events"

export class LLMService extends EventEmitter {
  constructor() {
    super()
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    })
    this.together = new Together({
      apiKey: process.env.TOGETHER_API_KEY,
    })
    this.conversationHistory = []
  }

  async initialize() {
    console.log("🧠 Initializing LLM service...")

    // Test OpenAI connection
    try {
      await this.openai.models.list()
      console.log("✅ OpenAI LLM service initialized")
    } catch (error) {
      console.warn("⚠️ OpenAI connection failed, trying Together AI...")
    }
  }

  async generateResponse(userInput, useStreaming = true) {
    const startTime = Date.now()

    // Add user message to conversation history
    this.conversationHistory.push({
      role: "user",
      content: userInput,
      timestamp: Date.now(),
    })

    const messages = [
      {
        role: "system",
        content:
          "You are a helpful AI assistant. Keep responses concise, natural, and conversational. Aim for responses under 50 words when possible.",
      },
      ...this.conversationHistory.slice(-10), // Keep last 10 messages for context
    ]

    try {
      if (useStreaming) {
        return await this.generateStreamingResponse(messages, startTime)
      } else {
        return await this.generateCompleteResponse(messages, startTime)
      }
    } catch (error) {
      console.error("❌ LLM Error:", error)
      throw error
    }
  }

  async generateStreamingResponse(messages, startTime) {
    const stream = await this.openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      stream: true,
      max_tokens: 150,
      temperature: 0.7,
    })

    let fullResponse = ""
    let firstTokenTime = null

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || ""
      if (content) {
        if (!firstTokenTime) {
          firstTokenTime = Date.now()
          const ttft = firstTokenTime - startTime // Time to First Token
          this.emit("first_token", { ttft, timestamp: firstTokenTime })
        }

        fullResponse += content
        this.emit("token", {
          content,
          full_response: fullResponse,
          timestamp: Date.now(),
        })
      }
    }

    // Add assistant response to conversation history
    this.conversationHistory.push({
      role: "assistant",
      content: fullResponse,
      timestamp: Date.now(),
    })

    const totalLatency = Date.now() - startTime

    return {
      text: fullResponse,
      latency: totalLatency,
      ttft: firstTokenTime ? firstTokenTime - startTime : null,
      timestamp: Date.now(),
    }
  }

  async generateCompleteResponse(messages, startTime) {
    const response = await this.openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages,
      max_tokens: 150,
      temperature: 0.7,
    })

    const responseText = response.choices[0].message.content
    const latency = Date.now() - startTime

    // Add assistant response to conversation history
    this.conversationHistory.push({
      role: "assistant",
      content: responseText,
      timestamp: Date.now(),
    })

    return {
      text: responseText,
      latency,
      timestamp: Date.now(),
    }
  }

  clearHistory() {
    this.conversationHistory = []
  }
}
