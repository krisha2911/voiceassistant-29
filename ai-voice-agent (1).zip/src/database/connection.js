import { neon } from "@neondatabase/serverless"

export class DatabaseConnection {
  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is required")
    }

    this.sql = neon(process.env.DATABASE_URL)
    console.log("📊 Database connection initialized")
  }

  async testConnection() {
    try {
      const result = await this.sql`SELECT NOW() as current_time`
      console.log("✅ Database connection successful:", result[0].current_time)
      return true
    } catch (error) {
      console.error("❌ Database connection failed:", error)
      return false
    }
  }

  async createSession(participantId) {
    try {
      const result = await this.sql`
        INSERT INTO sessions (participant_id, start_time)
        VALUES (${participantId}, NOW())
        RETURNING id, start_time
      `

      console.log(`📝 Created session ${result[0].id} for ${participantId}`)
      return result[0]
    } catch (error) {
      console.error("❌ Failed to create session:", error)
      throw error
    }
  }

  async endSession(sessionId) {
    try {
      const result = await this.sql`
        UPDATE sessions 
        SET end_time = NOW(),
            duration_ms = EXTRACT(EPOCH FROM (NOW() - start_time)) * 1000
        WHERE id = ${sessionId}
        RETURNING duration_ms
      `

      if (result.length > 0) {
        console.log(`📝 Ended session ${sessionId}, duration: ${result[0].duration_ms}ms`)
        return result[0].duration_ms
      }
    } catch (error) {
      console.error("❌ Failed to end session:", error)
      throw error
    }
  }

  async logMetric(sessionId, metricType, data) {
    try {
      const result = await this.sql`
        INSERT INTO metrics (
          session_id, 
          metric_type, 
          latency_ms, 
          ttft_ms, 
          ttfb_ms, 
          additional_data,
          timestamp_recorded
        )
        VALUES (
          ${sessionId},
          ${metricType},
          ${data.latency || null},
          ${data.ttft || null},
          ${data.ttfb || null},
          ${JSON.stringify(data)},
          ${data.timestamp ? new Date(data.timestamp) : new Date()}
        )
        RETURNING id
      `

      return result[0].id
    } catch (error) {
      console.error("❌ Failed to log metric:", error)
      throw error
    }
  }

  async logConversation(sessionId, userInput, aiResponse, metrics) {
    try {
      const result = await this.sql`
        INSERT INTO conversations (
          session_id,
          user_input,
          ai_response,
          total_pipeline_latency_ms,
          stt_latency_ms,
          llm_latency_ms,
          tts_latency_ms,
          timestamp_started,
          timestamp_completed
        )
        VALUES (
          ${sessionId},
          ${userInput},
          ${aiResponse},
          ${metrics.total_latency},
          ${metrics.stt_latency},
          ${metrics.llm_latency},
          ${metrics.tts_latency},
          ${new Date(metrics.start_time)},
          NOW()
        )
        RETURNING id
      `

      return result[0].id
    } catch (error) {
      console.error("❌ Failed to log conversation:", error)
      throw error
    }
  }

  async logError(sessionId, errorType, errorMessage, errorStack) {
    try {
      const result = await this.sql`
        INSERT INTO errors (session_id, error_type, error_message, error_stack)
        VALUES (${sessionId}, ${errorType}, ${errorMessage}, ${errorStack})
        RETURNING id
      `

      return result[0].id
    } catch (error) {
      console.error("❌ Failed to log error:", error)
      throw error
    }
  }

  async getSessionMetrics(sessionId) {
    try {
      const result = await this.sql`
        SELECT * FROM metrics_summary 
        WHERE session_id = ${sessionId}
      `

      return result[0] || null
    } catch (error) {
      console.error("❌ Failed to get session metrics:", error)
      throw error
    }
  }

  async getAllMetrics(limit = 1000) {
    try {
      const result = await this.sql`
        SELECT 
          m.*,
          s.participant_id,
          s.start_time as session_start
        FROM metrics m
        JOIN sessions s ON m.session_id = s.id
        ORDER BY m.timestamp_recorded DESC
        LIMIT ${limit}
      `

      return result
    } catch (error) {
      console.error("❌ Failed to get all metrics:", error)
      throw error
    }
  }

  async getPerformanceStats() {
    try {
      const result = await this.sql`
        SELECT 
          COUNT(*) as total_sessions,
          AVG(duration_ms) as avg_session_duration,
          AVG(average_latency) as overall_avg_latency,
          SUM(total_interactions) as total_interactions,
          SUM(error_count) as total_errors,
          (SUM(total_interactions) - SUM(error_count))::DECIMAL / NULLIF(SUM(total_interactions), 0) * 100 as success_rate
        FROM sessions
        WHERE end_time IS NOT NULL
      `

      return result[0]
    } catch (error) {
      console.error("❌ Failed to get performance stats:", error)
      throw error
    }
  }

  async getLatencyBreakdown() {
    try {
      const result = await this.sql`
        SELECT 
          metric_type,
          COUNT(*) as count,
          AVG(latency_ms) as avg_latency,
          MIN(latency_ms) as min_latency,
          MAX(latency_ms) as max_latency,
          PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY latency_ms) as median_latency,
          PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY latency_ms) as p95_latency
        FROM metrics 
        WHERE latency_ms IS NOT NULL
        GROUP BY metric_type
        ORDER BY avg_latency DESC
      `

      return result
    } catch (error) {
      console.error("❌ Failed to get latency breakdown:", error)
      throw error
    }
  }

  async getRecentErrors(limit = 50) {
    try {
      const result = await this.sql`
        SELECT 
          e.*,
          s.participant_id
        FROM errors e
        LEFT JOIN sessions s ON e.session_id = s.id
        ORDER BY e.timestamp_occurred DESC
        LIMIT ${limit}
      `

      return result
    } catch (error) {
      console.error("❌ Failed to get recent errors:", error)
      throw error
    }
  }
}
