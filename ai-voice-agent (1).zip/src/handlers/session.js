import { EventEmitter } from "events"
import { v4 as uuidv4 } from "uuid"

export class SessionHandler extends EventEmitter {
  constructor({ stt, llm, tts, metrics }) {
    super()
    this.stt = stt
    this.llm = llm
    this.tts = tts
    this.metrics = metrics
    this.sessions = new Map()
    this.setupEventHandlers()
  }

  setupEventHandlers() {
    // STT Events
    this.stt.on("transcript", (data) => {
      this.handleTranscript(data)
    })

    // LLM Events
    this.llm.on("first_token", (data) => {
      this.metrics.logMetric("llm_first_token", data)
    })

    this.llm.on("token", (data) => {
      this.emit("llm_token", data)
    })

    // TTS Events
    this.tts.on("first_byte", (data) => {
      this.metrics.logMetric("tts_first_byte", data)
    })

    this.tts.on("audio_chunk", (data) => {
      this.emit("audio_chunk", data)
    })
  }

  handleParticipantJoined(participant) {
    const sessionId = uuidv4()
    const session = {
      id: sessionId,
      participantId: participant.identity,
      startTime: Date.now(),
      conversationState: "idle",
      metrics: {
        totalInteractions: 0,
        averageLatency: 0,
        errors: 0,
      },
    }

    this.sessions.set(participant.identity, session)
    this.metrics.startSession(sessionId)

    console.log(`📝 New session created: ${sessionId} for ${participant.identity}`)
  }

  handleParticipantLeft(participant) {
    const session = this.sessions.get(participant.identity)
    if (session) {
      this.metrics.endSession(session.id)
      this.sessions.delete(participant.identity)
      console.log(`📝 Session ended: ${session.id}`)
    }
  }

  async handleTranscript(transcriptData) {
    if (!transcriptData.is_final) return

    const sessionStartTime = Date.now()

    try {
      // Log STT metrics
      this.metrics.logMetric("stt_latency", {
        latency: transcriptData.latency,
        timestamp: transcriptData.timestamp,
      })

      // Generate LLM response
      console.log(`🎤 User said: "${transcriptData.text}"`)
      const llmResponse = await this.llm.generateResponse(transcriptData.text)

      // Log LLM metrics
      this.metrics.logMetric("llm_latency", {
        latency: llmResponse.latency,
        ttft: llmResponse.ttft,
        timestamp: llmResponse.timestamp,
      })

      // Generate TTS audio
      console.log(`🤖 AI responds: "${llmResponse.text}"`)
      const ttsResponse = await this.tts.synthesizeSpeech(llmResponse.text)

      // Log TTS metrics
      this.metrics.logMetric("tts_latency", {
        latency: ttsResponse.latency,
        ttfb: ttsResponse.ttfb,
        timestamp: ttsResponse.timestamp,
      })

      // Calculate total pipeline latency
      const totalLatency = Date.now() - sessionStartTime
      this.metrics.logMetric("total_latency", {
        latency: totalLatency,
        timestamp: Date.now(),
      })

      console.log(`⏱️ Total pipeline latency: ${totalLatency}ms`)

      // Emit the complete response
      this.emit("response_complete", {
        transcript: transcriptData.text,
        response: llmResponse.text,
        audio: ttsResponse.audio,
        metrics: {
          stt_latency: transcriptData.latency,
          llm_latency: llmResponse.latency,
          llm_ttft: llmResponse.ttft,
          tts_latency: ttsResponse.latency,
          tts_ttfb: ttsResponse.ttfb,
          total_latency: totalLatency,
        },
      })
    } catch (error) {
      console.error("❌ Pipeline error:", error)
      this.metrics.logError(error)
      this.emit("error", error)
    }
  }

  // Handle interruptions by buffering input and resuming context
  handleInterruption(participantId) {
    const session = this.sessions.get(participantId)
    if (session) {
      session.conversationState = "interrupted"
      console.log(`⏸️ Conversation interrupted for ${participantId}`)

      // Stop current TTS if playing
      this.tts.emit("stop")

      // Buffer the interruption
      this.emit("conversation_interrupted", { sessionId: session.id })
    }
  }

  resumeConversation(participantId) {
    const session = this.sessions.get(participantId)
    if (session) {
      session.conversationState = "active"
      console.log(`▶️ Conversation resumed for ${participantId}`)
      this.emit("conversation_resumed", { sessionId: session.id })
    }
  }
}
