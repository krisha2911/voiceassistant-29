import { DatabaseConnection } from "./database/connection.js"
import { MetricsLogger } from "./utils/metrics.js"
import { faker } from "faker"
import dotenv from "dotenv"

dotenv.config()

class DatabaseTester {
  constructor() {
    this.db = new DatabaseConnection()
    this.metrics = new MetricsLogger()
  }

  async testDatabaseConnection() {
    console.log("🧪 Testing database connection...")
    const isConnected = await this.db.testConnection()

    if (!isConnected) {
      throw new Error("Database connection failed")
    }

    console.log("✅ Database connection successful")
  }

  async generateAdditionalDummyData() {
    console.log("🎭 Generating additional dummy data...")

    const participants = ["user_frank", "user_grace", "user_henry", "user_iris", "user_jack"]

    for (const participant of participants) {
      console.log(`👤 Creating session for ${participant}`)

      // Create session
      const session = await this.db.createSession(participant)
      const sessionId = session.id

      // Generate random number of conversations (5-20)
      const numConversations = faker.datatype.number({ min: 5, max: 20 })

      for (let i = 0; i < numConversations; i++) {
        await this.generateRandomConversation(sessionId)

        // Random delay between conversations
        await new Promise((resolve) => setTimeout(resolve, faker.datatype.number({ min: 100, max: 500 })))
      }

      // End session
      await this.db.endSession(sessionId)

      // Occasionally add errors
      if (faker.datatype.boolean()) {
        await this.generateRandomError(sessionId)
      }
    }

    console.log("✅ Additional dummy data generated")
  }

  async generateRandomConversation(sessionId) {
    const userInputs = [
      "Hello, how are you?",
      "What's the weather like today?",
      "Tell me a joke",
      "How do I cook pasta?",
      "What's 15 times 23?",
      "Explain machine learning",
      "Recommend a good book",
      "What time is it?",
      "Help me with my homework",
      "Tell me about space",
      "How do I learn programming?",
      "What's your favorite color?",
      "Sing me a song",
      "What's the capital of France?",
      "How do I make coffee?",
    ]

    const aiResponses = [
      "I'm doing great, thank you for asking!",
      "I don't have access to current weather data, but you can check your local weather app.",
      "Why don't scientists trust atoms? Because they make up everything!",
      "Boil water, add salt, cook pasta according to package directions, then drain and serve.",
      "15 times 23 equals 345.",
      "Machine learning is a type of AI that learns patterns from data to make predictions.",
      "I'd recommend 'The Midnight Library' by Matt Haig - it's a fascinating read!",
      "I don't have access to the current time, but you can check your device's clock.",
      "I'd be happy to help! What subject do you need assistance with?",
      "Space is vast and full of amazing phenomena like stars, planets, and galaxies.",
      "Start with basics like Python or JavaScript, practice regularly, and build projects.",
      "I don't have personal preferences, but blue is often considered calming and popular.",
      "I can't sing, but I can suggest some great songs or help you find lyrics!",
      "The capital of France is Paris, a beautiful city known for art and culture.",
      "Grind coffee beans, add hot water, let it brew, then filter and enjoy!",
    ]

    const userInput = faker.random.arrayElement(userInputs)
    const aiResponse = faker.random.arrayElement(aiResponses)

    // Generate realistic latencies with some variation
    const sttLatency = faker.datatype.number({ min: 80, max: 300 })
    const llmLatency = faker.datatype.number({ min: 300, max: 1200 })
    const ttsLatency = faker.datatype.number({ min: 200, max: 600 })
    const totalLatency = sttLatency + llmLatency + ttsLatency + faker.datatype.number({ min: 50, max: 200 })

    const metrics = {
      stt_latency: sttLatency,
      llm_latency: llmLatency,
      tts_latency: ttsLatency,
      total_latency: totalLatency,
      start_time: Date.now() - totalLatency,
    }

    // Log conversation to database
    await this.db.logConversation(sessionId, userInput, aiResponse, metrics)

    // Log individual metrics
    await this.db.logMetric(sessionId, "stt_latency", {
      latency: sttLatency,
      confidence: faker.datatype.float({ min: 0.8, max: 0.99 }),
      language: "en-US",
    })

    await this.db.logMetric(sessionId, "llm_latency", {
      latency: llmLatency,
      ttft: faker.datatype.number({ min: 50, max: 200 }),
      model: "gpt-4o-mini",
      tokens: faker.datatype.number({ min: 20, max: 80 }),
    })

    await this.db.logMetric(sessionId, "tts_latency", {
      latency: ttsLatency,
      ttfb: faker.datatype.number({ min: 30, max: 150 }),
      voice_id: "pNInz6obpgDQGcFmaJgB",
      characters: aiResponse.length,
    })

    await this.db.logMetric(sessionId, "total_latency", {
      latency: totalLatency,
      pipeline_complete: true,
    })

    console.log(`💬 Generated conversation: "${userInput}" -> "${aiResponse}" (${totalLatency}ms)`)
  }

  async generateRandomError(sessionId) {
    const errorTypes = [
      "STT_TIMEOUT",
      "LLM_RATE_LIMIT",
      "TTS_API_ERROR",
      "NETWORK_ERROR",
      "STT_LOW_CONFIDENCE",
      "LLM_CONTEXT_LIMIT",
      "TTS_VOICE_UNAVAILABLE",
    ]

    const errorMessages = [
      "Speech recognition service timeout",
      "API rate limit exceeded",
      "Text-to-speech service unavailable",
      "Network connection lost",
      "Speech recognition confidence too low",
      "Context window size exceeded",
      "Selected voice model unavailable",
    ]

    const errorType = faker.random.arrayElement(errorTypes)
    const errorMessage = faker.random.arrayElement(errorMessages)
    const errorStack = `Error: ${errorMessage}\n    at Function.test (/app/src/test.js:123:45)`

    await this.db.logError(sessionId, errorType, errorMessage, errorStack)
    console.log(`❌ Generated error: ${errorType} - ${errorMessage}`)
  }

  async runMetricsAnalysis() {
    console.log("\n📊 Running database metrics analysis...")

    const dbMetrics = await this.metrics.getDatabaseMetrics()

    if (!dbMetrics) {
      console.log("❌ Could not retrieve database metrics")
      return
    }

    console.log("\n📈 PERFORMANCE OVERVIEW")
    console.log("=" * 50)
    console.log(`Total Sessions: ${dbMetrics.performance.total_sessions}`)
    console.log(`Total Interactions: ${dbMetrics.performance.total_interactions}`)
    console.log(`Total Errors: ${dbMetrics.performance.total_errors}`)
    console.log(`Success Rate: ${Number.parseFloat(dbMetrics.performance.success_rate).toFixed(1)}%`)
    console.log(`Average Session Duration: ${Math.round(dbMetrics.performance.avg_session_duration / 1000)}s`)
    console.log(`Overall Average Latency: ${Number.parseFloat(dbMetrics.performance.overall_avg_latency).toFixed(1)}ms`)

    console.log("\n🔍 LATENCY BREAKDOWN")
    console.log("=" * 50)
    dbMetrics.latencyBreakdown.forEach((metric) => {
      console.log(`${metric.metric_type.toUpperCase()}:`)
      console.log(`  Count: ${metric.count}`)
      console.log(`  Average: ${Number.parseFloat(metric.avg_latency).toFixed(1)}ms`)
      console.log(`  Median: ${Number.parseFloat(metric.median_latency).toFixed(1)}ms`)
      console.log(`  95th Percentile: ${Number.parseFloat(metric.p95_latency).toFixed(1)}ms`)
      console.log(
        `  Range: ${Number.parseFloat(metric.min_latency).toFixed(1)}ms - ${Number.parseFloat(metric.max_latency).toFixed(1)}ms`,
      )
      console.log("")
    })

    if (dbMetrics.recentErrors.length > 0) {
      console.log("\n❌ RECENT ERRORS")
      console.log("=" * 50)
      dbMetrics.recentErrors.slice(0, 5).forEach((error) => {
        console.log(`${error.error_type}: ${error.error_message}`)
        console.log(`  Participant: ${error.participant_id || "Unknown"}`)
        console.log(`  Time: ${new Date(error.timestamp_occurred).toLocaleString()}`)
        console.log("")
      })
    }

    // Performance grading
    const avgLatency = Number.parseFloat(dbMetrics.performance.overall_avg_latency)
    const successRate = Number.parseFloat(dbMetrics.performance.success_rate)

    let grade = "F"
    if (avgLatency < 1000 && successRate > 95) grade = "A+"
    else if (avgLatency < 1500 && successRate > 90) grade = "A"
    else if (avgLatency < 2000 && successRate > 85) grade = "B"
    else if (avgLatency < 2500 && successRate > 80) grade = "C"
    else if (avgLatency < 3000 && successRate > 70) grade = "D"

    console.log("\n🎯 PERFORMANCE GRADE")
    console.log("=" * 50)
    console.log(`Overall Grade: ${grade}`)

    if (grade === "A+") {
      console.log("🏆 Excellent performance! Your agent is operating at peak efficiency.")
    } else if (grade === "A") {
      console.log("🌟 Very good performance! Minor optimizations could push you to A+.")
    } else if (grade === "B") {
      console.log("👍 Good performance, but there's room for improvement.")
    } else {
      console.log("⚠️ Performance needs improvement. Focus on reducing latency and errors.")
    }
  }

  async exportDatabaseMetricsToExcel() {
    console.log("\n📄 Exporting database metrics to Excel...")

    try {
      const allMetrics = await this.db.getAllMetrics(5000)

      // Convert to format expected by existing Excel export
      const formattedMetrics = allMetrics.map((metric) => ({
        Timestamp: new Date(metric.timestamp_recorded).toISOString(),
        "Metric Type": metric.metric_type,
        "Latency (ms)": metric.latency_ms || "",
        "TTFT (ms)": metric.ttft_ms || "",
        "TTFB (ms)": metric.ttfb_ms || "",
        Participant: metric.participant_id,
        "Additional Data": JSON.stringify(metric.additional_data || {}),
      }))

      // Use existing Excel export functionality
      const ExcelJS = (await import("exceljs")).default
      const workbook = new ExcelJS.Workbook()
      const worksheet = workbook.addWorksheet("Database Metrics")

      worksheet.columns = [
        { header: "Timestamp", key: "Timestamp", width: 20 },
        { header: "Metric Type", key: "Metric Type", width: 15 },
        { header: "Latency (ms)", key: "Latency (ms)", width: 12 },
        { header: "TTFT (ms)", key: "TTFT (ms)", width: 12 },
        { header: "TTFB (ms)", key: "TTFB (ms)", width: 12 },
        { header: "Participant", key: "Participant", width: 15 },
        { header: "Additional Data", key: "Additional Data", width: 30 },
      ]

      formattedMetrics.forEach((metric) => {
        worksheet.addRow(metric)
      })

      const filename = `data/database_metrics_${Date.now()}.xlsx`
      await workbook.xlsx.writeFile(filename)

      console.log(`📊 Database metrics exported to: ${filename}`)
      return filename
    } catch (error) {
      console.error("❌ Failed to export database metrics:", error)
      throw error
    }
  }
}

async function runDatabaseTests() {
  const tester = new DatabaseTester()

  try {
    console.log("🚀 Starting Database Testing Suite")
    console.log("=" * 50)

    // Test database connection
    await tester.testDatabaseConnection()

    // Generate additional dummy data
    await tester.generateAdditionalDummyData()

    // Run metrics analysis
    await tester.runMetricsAnalysis()

    // Export to Excel
    await tester.exportDatabaseMetricsToExcel()

    console.log("\n✅ Database testing completed successfully!")
    console.log("\n💡 Next Steps:")
    console.log("  1. Review the performance analysis above")
    console.log("  2. Check the exported Excel file for detailed metrics")
    console.log("  3. Use the insights to optimize your agent")
    console.log("  4. Run the Python analysis script for visualizations")
  } catch (error) {
    console.error("❌ Database testing failed:", error)
    process.exit(1)
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runDatabaseTests()
}

export { DatabaseTester }
