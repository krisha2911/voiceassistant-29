import { Agent, WorkerOptions, cli } from "@livekit/agents"
import { AutoSubscribe, WorkerType } from "@livekit/agents"
import { VoicePipelineAgent } from "@livekit/agents/plugins"
import dotenv from "dotenv"
import { STTService } from "./services/stt.js"
import { LLMService } from "./services/llm.js"
import { TTSService } from "./services/tts.js"
import { MetricsLogger } from "./utils/metrics.js"
import { SessionHandler } from "./handlers/session.js"

dotenv.config()

class AIVoiceAgent extends Agent {
  constructor() {
    super()
    this.sttService = new STTService()
    this.llmService = new LLMService()
    this.ttsService = new TTSService()
    this.metricsLogger = new MetricsLogger()
    this.sessionHandler = new SessionHandler({
      stt: this.sttService,
      llm: this.llmService,
      tts: this.ttsService,
      metrics: this.metricsLogger,
    })
  }

  async start(ctx) {
    console.log("🤖 AI Voice Agent starting...")

    // Initialize services
    await this.sttService.initialize()
    await this.llmService.initialize()
    await this.ttsService.initialize()

    console.log("✅ All services initialized")

    // Set up the voice pipeline
    const pipeline = new VoicePipelineAgent({
      stt: this.sttService,
      llm: this.llmService,
      tts: this.ttsService,
      chatCtx: {
        messages: [
          {
            role: "system",
            content: "You are a helpful AI assistant. Keep responses concise and conversational.",
          },
        ],
      },
    })

    // Handle room events
    ctx.room.on("participantConnected", (participant) => {
      console.log(`👤 Participant connected: ${participant.identity}`)
      this.sessionHandler.handleParticipantJoined(participant)
    })

    ctx.room.on("participantDisconnected", (participant) => {
      console.log(`👋 Participant disconnected: ${participant.identity}`)
      this.sessionHandler.handleParticipantLeft(participant)
    })

    // Start the pipeline
    pipeline.start(ctx.room)

    console.log("🎙️ Voice pipeline started and ready for conversations")
  }
}

// Worker configuration
const worker = new WorkerOptions({
  agent_name: "ai-voice-agent",
  worker_type: WorkerType.ROOM,
  auto_subscribe: AutoSubscribe.AUDIO_ONLY,
})

// Start the agent
async function main() {
  const agent = new AIVoiceAgent()

  await cli.run_app(worker, async (ctx) => {
    await agent.start(ctx)
  })
}

main().catch(console.error)
