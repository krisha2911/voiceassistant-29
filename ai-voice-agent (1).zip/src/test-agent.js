import { STTService } from "./services/stt.js"
import { LLMService } from "./services/llm.js"
import { TTSService } from "./services/tts.js"
import { MetricsLogger } from "./utils/metrics.js"
import dotenv from "dotenv"

dotenv.config()

class AgentTester {
  constructor() {
    this.stt = new STTService()
    this.llm = new LLMService()
    this.tts = new TTSService()
    this.metrics = new MetricsLogger()
  }

  async initialize() {
    console.log("🧪 Initializing Agent Tester...")
    await this.stt.initialize()
    await this.llm.initialize()
    await this.tts.initialize()
    console.log("✅ All services initialized for testing")
  }

  async testPipeline() {
    console.log("\n🔬 Testing complete STT → LLM → TTS pipeline...")

    const testInputs = [
      "Hello, how are you today?",
      "What's the weather like?",
      "Tell me a short joke",
      "Explain quantum computing in simple terms",
      "What's your favorite color?",
    ]

    const sessionId = "test-session-" + Date.now()
    this.metrics.startSession(sessionId)

    for (const input of testInputs) {
      console.log(`\n📝 Testing input: "${input}"`)
      await this.testSingleInteraction(input)

      // Wait between tests
      await new Promise((resolve) => setTimeout(resolve, 1000))
    }

    this.metrics.endSession(sessionId)

    // Print statistics
    const stats = this.metrics.getLatencyStats()
    if (stats) {
      console.log("\n📊 Test Results:")
      console.log(`Average Latency: ${stats.average}ms`)
      console.log(`Min Latency: ${stats.minimum}ms`)
      console.log(`Max Latency: ${stats.maximum}ms`)
      console.log(`Under 2s: ${stats.under2s}/${stats.count} (${Math.round((stats.under2s / stats.count) * 100)}%)`)
      console.log(`Over 2s: ${stats.over2s}/${stats.count} (${Math.round((stats.over2s / stats.count) * 100)}%)`)
    }

    // Export metrics
    await this.metrics.exportAllMetricsToExcel()
  }

  async testSingleInteraction(input) {
    const startTime = Date.now()

    try {
      // Simulate STT (we're providing text directly)
      const sttLatency = Math.random() * 200 + 100 // Simulate 100-300ms STT latency
      this.metrics.logMetric("stt_latency", {
        latency: sttLatency,
        timestamp: Date.now(),
      })

      // Test LLM
      console.log("🧠 Generating LLM response...")
      const llmResponse = await this.llm.generateResponse(input)
      this.metrics.logMetric("llm_latency", {
        latency: llmResponse.latency,
        ttft: llmResponse.ttft,
        timestamp: llmResponse.timestamp,
      })

      // Test TTS
      console.log("🔊 Generating TTS audio...")
      const ttsResponse = await this.tts.synthesizeSpeech(llmResponse.text)
      this.metrics.logMetric("tts_latency", {
        latency: ttsResponse.latency,
        ttfb: ttsResponse.ttfb,
        timestamp: ttsResponse.timestamp,
      })

      // Calculate total latency
      const totalLatency = Date.now() - startTime
      this.metrics.logMetric("total_latency", {
        latency: totalLatency,
        timestamp: Date.now(),
      })

      console.log(`✅ Response: "${llmResponse.text}"`)
      console.log(`⏱️ Total time: ${totalLatency}ms`)
    } catch (error) {
      console.error("❌ Test failed:", error)
      this.metrics.logError(error)
    }
  }

  async testLatencyOptimization() {
    console.log("\n⚡ Testing latency optimization strategies...")

    // Test different strategies
    const strategies = [
      { name: "Standard", streaming: false },
      { name: "Streaming LLM", streaming: true },
      { name: "Parallel Processing", parallel: true },
    ]

    for (const strategy of strategies) {
      console.log(`\n🧪 Testing strategy: ${strategy.name}`)

      const results = []
      for (let i = 0; i < 5; i++) {
        const result = await this.testLatencyStrategy(strategy, `Test message ${i + 1}`)
        results.push(result)
      }

      const avgLatency = results.reduce((sum, r) => sum + r.totalLatency, 0) / results.length
      console.log(`📊 ${strategy.name} average latency: ${Math.round(avgLatency)}ms`)
    }
  }

  async testLatencyStrategy(strategy, input) {
    const startTime = Date.now()

    try {
      if (strategy.parallel) {
        // Test parallel processing where possible
        const [llmResponse] = await Promise.all([
          this.llm.generateResponse(input, strategy.streaming),
          // Could add other parallel operations here
        ])

        const ttsResponse = await this.tts.synthesizeSpeech(llmResponse.text, true)

        return {
          totalLatency: Date.now() - startTime,
          llmLatency: llmResponse.latency,
          ttsLatency: ttsResponse.latency,
        }
      } else {
        const llmResponse = await this.llm.generateResponse(input, strategy.streaming)
        const ttsResponse = await this.tts.synthesizeSpeech(llmResponse.text, true)

        return {
          totalLatency: Date.now() - startTime,
          llmLatency: llmResponse.latency,
          ttsLatency: ttsResponse.latency,
        }
      }
    } catch (error) {
      console.error(`❌ Strategy ${strategy.name} failed:`, error)
      return { totalLatency: Number.POSITIVE_INFINITY, error: error.message }
    }
  }
}

// Run tests
async function runTests() {
  const tester = new AgentTester()

  try {
    await tester.initialize()
    await tester.testPipeline()
    await tester.testLatencyOptimization()

    console.log("\n✅ All tests completed!")
  } catch (error) {
    console.error("❌ Test suite failed:", error)
    process.exit(1)
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runTests()
}

export { AgentTester }
