import ExcelJS from "exceljs"
import winston from "winston"
import fs from "fs/promises"
import { DatabaseConnection } from "../database/connection.js"

export class MetricsLogger {
  constructor() {
    this.sessions = new Map()
    this.metricsData = []

    // Initialize database connection
    try {
      this.db = new DatabaseConnection()
    } catch (error) {
      console.warn("⚠️ Database connection failed, falling back to file-only logging:", error.message)
      this.db = null
    }

    // Setup Winston logger
    this.logger = winston.createLogger({
      level: "info",
      format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
      transports: [new winston.transports.File({ filename: "logs/metrics.log" }), new winston.transports.Console()],
    })

    // Ensure logs directory exists
    this.ensureDirectories()
  }

  async ensureDirectories() {
    try {
      await fs.mkdir("logs", { recursive: true })
      await fs.mkdir("data", { recursive: true })
    } catch (error) {
      console.warn("Could not create directories:", error.message)
    }
  }

  async startSession(sessionId, participantId = "unknown") {
    const session = {
      id: sessionId,
      participantId,
      startTime: Date.now(),
      metrics: [],
      errors: [],
    }

    this.sessions.set(sessionId, session)

    // Store in database if available
    if (this.db) {
      try {
        const dbSession = await this.db.createSession(participantId)
        session.dbId = dbSession.id
        console.log(`📊 Session ${sessionId} stored in database with ID: ${dbSession.id}`)
      } catch (error) {
        console.warn("⚠️ Failed to store session in database:", error.message)
      }
    }

    return session
  }

  async endSession(sessionId) {
    const session = this.sessions.get(sessionId)
    if (session) {
      session.endTime = Date.now()
      session.duration = session.endTime - session.startTime

      // Update database if available
      if (this.db && session.dbId) {
        try {
          await this.db.endSession(session.dbId)
        } catch (error) {
          console.warn("⚠️ Failed to update session in database:", error.message)
        }
      }

      // Export session metrics to Excel
      await this.exportSessionToExcel(session)

      this.sessions.delete(sessionId)
    }
  }

  async logMetric(type, data, sessionId = null) {
    const metric = {
      type,
      timestamp: Date.now(),
      ...data,
    }

    this.metricsData.push(metric)

    // Store in database if available
    if (this.db && sessionId) {
      const session = this.sessions.get(sessionId)
      if (session && session.dbId) {
        try {
          await this.db.logMetric(session.dbId, type, data)
        } catch (error) {
          console.warn("⚠️ Failed to store metric in database:", error.message)
        }
      }
    }

    // Log to Winston
    this.logger.info("Metric logged", metric)

    // Log specific metrics with context
    switch (type) {
      case "stt_latency":
        console.log(`📊 STT Latency: ${data.latency}ms`)
        break
      case "llm_latency":
        console.log(`📊 LLM Latency: ${data.latency}ms (TTFT: ${data.ttft}ms)`)
        break
      case "tts_latency":
        console.log(`📊 TTS Latency: ${data.latency}ms (TTFB: ${data.ttfb}ms)`)
        break
      case "total_latency":
        const status = data.latency < 2000 ? "✅" : "⚠️"
        console.log(`📊 ${status} Total Latency: ${data.latency}ms`)
        break
    }
  }

  logError(error) {
    const errorData = {
      type: "error",
      message: error.message,
      stack: error.stack,
      timestamp: Date.now(),
    }

    this.metricsData.push(errorData)
    this.logger.error("Error logged", errorData)
  }

  async exportSessionToExcel(session) {
    try {
      const workbook = new ExcelJS.Workbook()
      const worksheet = workbook.addWorksheet("Session Metrics")

      // Add headers
      worksheet.columns = [
        { header: "Timestamp", key: "timestamp", width: 20 },
        { header: "Metric Type", key: "type", width: 15 },
        { header: "Latency (ms)", key: "latency", width: 12 },
        { header: "TTFT (ms)", key: "ttft", width: 12 },
        { header: "TTFB (ms)", key: "ttfb", width: 12 },
        { header: "Additional Data", key: "data", width: 30 },
      ]

      // Add session metrics
      session.metrics.forEach((metric) => {
        worksheet.addRow({
          timestamp: new Date(metric.timestamp).toISOString(),
          type: metric.type,
          latency: metric.latency || "",
          ttft: metric.ttft || "",
          ttfb: metric.ttfb || "",
          data: JSON.stringify(metric),
        })
      })

      // Add summary row
      const avgLatency = this.calculateAverageLatency(session.metrics)
      worksheet.addRow({
        timestamp: "SUMMARY",
        type: "Average",
        latency: avgLatency,
        ttft: "",
        ttfb: "",
        data: `Session Duration: ${session.duration}ms`,
      })

      // Save to file
      const filename = `data/session_${session.id}_${Date.now()}.xlsx`
      await workbook.xlsx.writeFile(filename)

      console.log(`📊 Session metrics exported to: ${filename}`)
    } catch (error) {
      console.error("❌ Failed to export metrics to Excel:", error)
    }
  }

  calculateAverageLatency(metrics) {
    const latencyMetrics = metrics.filter((m) => m.latency)
    if (latencyMetrics.length === 0) return 0

    const total = latencyMetrics.reduce((sum, m) => sum + m.latency, 0)
    return Math.round(total / latencyMetrics.length)
  }

  async exportAllMetricsToExcel() {
    try {
      const workbook = new ExcelJS.Workbook()
      const worksheet = workbook.addWorksheet("All Metrics")

      worksheet.columns = [
        { header: "Timestamp", key: "timestamp", width: 20 },
        { header: "Type", key: "type", width: 15 },
        { header: "Latency (ms)", key: "latency", width: 12 },
        { header: "TTFT (ms)", key: "ttft", width: 12 },
        { header: "TTFB (ms)", key: "ttfb", width: 12 },
        { header: "Data", key: "data", width: 50 },
      ]

      this.metricsData.forEach((metric) => {
        worksheet.addRow({
          timestamp: new Date(metric.timestamp).toISOString(),
          type: metric.type,
          latency: metric.latency || "",
          ttft: metric.ttft || "",
          ttfb: metric.ttfb || "",
          data: JSON.stringify(metric),
        })
      })

      const filename = `data/all_metrics_${Date.now()}.xlsx`
      await workbook.xlsx.writeFile(filename)

      console.log(`📊 All metrics exported to: ${filename}`)
      return filename
    } catch (error) {
      console.error("❌ Failed to export all metrics:", error)
      throw error
    }
  }

  getLatencyStats() {
    const latencyMetrics = this.metricsData.filter((m) => m.latency)
    if (latencyMetrics.length === 0) return null

    const latencies = latencyMetrics.map((m) => m.latency)
    const avg = latencies.reduce((a, b) => a + b, 0) / latencies.length
    const min = Math.min(...latencies)
    const max = Math.max(...latencies)

    return {
      average: Math.round(avg),
      minimum: min,
      maximum: max,
      count: latencies.length,
      under2s: latencies.filter((l) => l < 2000).length,
      over2s: latencies.filter((l) => l >= 2000).length,
    }
  }

  async logConversation(sessionId, userInput, aiResponse, metrics) {
    if (this.db) {
      const session = this.sessions.get(sessionId)
      if (session && session.dbId) {
        try {
          await this.db.logConversation(session.dbId, userInput, aiResponse, metrics)
          console.log(`💬 Conversation logged to database`)
        } catch (error) {
          console.warn("⚠️ Failed to log conversation to database:", error.message)
        }
      }
    }
  }

  async getDatabaseMetrics() {
    if (!this.db) {
      console.warn("⚠️ Database not available")
      return null
    }

    try {
      const [stats, breakdown, errors] = await Promise.all([
        this.db.getPerformanceStats(),
        this.db.getLatencyBreakdown(),
        this.db.getRecentErrors(10),
      ])

      return {
        performance: stats,
        latencyBreakdown: breakdown,
        recentErrors: errors,
      }
    } catch (error) {
      console.error("❌ Failed to get database metrics:", error)
      return null
    }
  }
}
